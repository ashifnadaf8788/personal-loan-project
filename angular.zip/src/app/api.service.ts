import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http:HttpClient) {

  }
  post=(api:string,data:any)=>{
   const headers = {'Content-type': 'application/json'}
   return this.http.post("http://apps.thinkoverit.com/api/getOTP.php", data, {'headers':headers});
 }



getOTP=()=>{
 return this.http.get("http://apps.thinkoverit.com/api/getOTP.php");
}
}
