import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ApiService } from './api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent 
{
  title = 'pixel6';
  formdata: any;
  inputvalue = "";
  enablebutton = false;
  timespent = 0;
  fullname:any;
  showresendbutton = false;
  registrationdone = true;
  Success1 = false;
  showalt =false;
  para:any;
  para2:any;
  count=1;


  constructor(private api: ApiService) {}

  ngOnInit(): void {
   this.formdata = new FormGroup(
     {
       city : new FormControl("",Validators.required),
       panNumber : new FormControl("",Validators.compose([Validators.required, Validators.pattern(/[A-Z]{5}[0-9]{4}[A-Z]{1}$/)])),
       fullname : new FormControl("",Validators.compose([Validators.required,Validators.maxLength(140)])),
       email: new FormControl("", Validators.compose([Validators.required, Validators.pattern(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/)])),
       mobile: new FormControl("", Validators.compose([Validators.required, Validators.pattern(/^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/)])),
       otp: new FormControl("", Validators.compose([Validators.required, Validators.min(4), Validators.max(4)]))
     }
   )
  }

 
  sendOTP(formdata : any)
  {
    
    if(formdata.controls.mobile.invalid == false)
    {
      this.timespent = 0;
      let para={
        "city": formdata.controls.city.value,
        "panNumber": formdata.controls.panNumber.value,
        "fullname" : formdata.controls.fullname.value,
        "email" :  formdata.controls.email.value,
        "mobile" : formdata.controls.mobile.value,
      }
      console.log(para);
      
      this.api.post("http://apps.thinkoverit.com/api/getOTP.php", para).subscribe((data: any) => {
      
       console.log(data);
       
      if (data.status == "Success") {
      
          let interval = setInterval(() => {
            this.timespent++;
            if (this.timespent < 180) {
              this.enablebutton = false;
              this.showresendbutton = false;
            } 
            else {
              this.enablebutton = true;
              this.showresendbutton = true;
              clearInterval(interval);
            }
            if (this.count==3){
              this.showresendbutton=false;
              this.showalt=true;
            }
            // let int =setInterval(() => {
            //   if (this.count==3){
            //     this.showresendbutton=false;
            //     this.showalt=true;
            //   }
            // }, 3000);
          }, 1000);
        }
        else{
          alert("Something went wrong.");
        }
      });


      
    }
  }

  verifyOTP(formdata: any) {
    if (formdata.invalid == true) {

      let para2 = {

        "mobile" : formdata.controls.mobile.value,
        "otp" : formdata.controls.mobile.value,
      }



      this.api.post("http://apps.thinkoverit.com/api/verifyOTP.php", para2).subscribe(
        (data: any) => {
          console.log(data);
          if (data.status == "Success"){
          this.registrationdone = false;
          this.Success1= true;
          this.fullname = formdata.controls.fullname.value;
          }else{
            alert("un varifide Otp")
          }
        }
      );
    }
    else{
      alert("err")
    }
  }
}
